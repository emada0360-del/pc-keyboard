package com.pckeyboard.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.drawable.GradientDrawable;
import android.inputmethodservice.InputMethodService;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class PcKeyboardService extends InputMethodService {

    private static final int CHAR = 0, ACT = 1, MOD = 2, LANG = 3, TOG = 4;
    private static final int SHIFT = 0, CTRL = 1, ALT = 2, CAPS = 3;

    private static class Key {
        int type;
        String en, ens, ar, ars;
        int code;
        int mod;
        String label;
        float w = 1f;
        int size = 15;
        TextView view;
        long downAt;
        boolean consumed;
        Runnable repeat;
        Runnable longPress;
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<Key> all = new ArrayList<>();
    private final boolean[] on = new boolean[3];
    private final boolean[] held = new boolean[3];
    private final boolean[] used = new boolean[3];
    private boolean caps = false;
    private boolean shiftA = true;
    private int lang = 0; // 0 = English, 1 = Arabic
    private int cTray, cKey, cMod, cActive, cText, cOnActive;
    private SharedPreferences sp;

    // ---------- key builders ----------
    private static Key c(String en, String ens, String ar, String ars, float w) {
        Key k = new Key();
        k.type = CHAR;
        k.en = en;
        k.ens = ens;
        k.ar = ar;
        k.ars = ars;
        k.w = w;
        return k;
    }

    private static Key c(String en, String ens, String ar, String ars) {
        return c(en, ens, ar, ars, 1f);
    }

    private static Key a(int code, String label, float w) {
        Key k = new Key();
        k.type = ACT;
        k.code = code;
        k.label = label;
        k.w = w;
        k.size = 11;
        return k;
    }

    private static Key m(int mod, String label, float w) {
        Key k = new Key();
        k.type = MOD;
        k.mod = mod;
        k.label = label;
        k.w = w;
        k.size = 11;
        return k;
    }

    private static Key special(int type, String label, float w) {
        Key k = new Key();
        k.type = type;
        k.label = label;
        k.w = w;
        k.size = 11;
        return k;
    }

    private Key[][] buildRows() {
        List<Key> fr = new ArrayList<>();
        fr.add(a(KeyEvent.KEYCODE_ESCAPE, "Esc", 1f));
        for (int i = 0; i < 12; i++) {
            fr.add(a(KeyEvent.KEYCODE_F1 + i, "F" + (i + 1), 1f));
        }
        for (Key k : fr) k.size = 10;
        Key tog = special(TOG, "⇧A", 1.3f);
        tog.size = 10;
        fr.add(tog);

        Key[] r0 = fr.toArray(new Key[0]);

        Key[] r1 = new Key[]{
                c("`", "~", "ذ", "ّ"), c("1", "!", "1", "!"), c("2", "@", "2", "@"),
                c("3", "#", "3", "#"), c("4", "$", "4", "$"), c("5", "%", "5", "%"),
                c("6", "^", "6", "^"), c("7", "&", "7", "&"), c("8", "*", "8", "*"),
                c("9", "(", "9", "("), c("0", ")", "0", ")"), c("-", "_", "-", "_"),
                c("=", "+", "=", "+"), a(KeyEvent.KEYCODE_DEL, "⌫", 2f)
        };
        Key[] r2 = new Key[]{
                a(KeyEvent.KEYCODE_TAB, "Tab", 1.5f),
                c("q", "Q", "ض", "َ"), c("w", "W", "ص", "ً"), c("e", "E", "ث", "ُ"),
                c("r", "R", "ق", "ٌ"), c("t", "T", "ف", "لإ"), c("y", "Y", "غ", "إ"),
                c("u", "U", "ع", "‘"), c("i", "I", "ه", "÷"), c("o", "O", "خ", "×"),
                c("p", "P", "ح", "؛"), c("[", "{", "ج", "<"), c("]", "}", "د", ">"),
                c("\\", "|", "\\", "|", 1.5f)
        };
        Key[] r3 = new Key[]{
                m(CAPS, "Caps", 1.75f),
                c("a", "A", "ش", "ِ"), c("s", "S", "س", "ٍ"), c("d", "D", "ي", "]"),
                c("f", "F", "ب", "["), c("g", "G", "ل", "لأ"), c("h", "H", "ا", "أ"),
                c("j", "J", "ت", "ـ"), c("k", "K", "ن", "،"), c("l", "L", "م", "/"),
                c(";", ":", "ك", ":"), c("'", "\"", "ط", "\""),
                a(KeyEvent.KEYCODE_ENTER, "Enter", 2.25f)
        };
        Key[] r4 = new Key[]{
                m(SHIFT, "Shift", 2.25f),
                c("z", "Z", "ئ", "~"), c("x", "X", "ء", "ْ"), c("c", "C", "ؤ", "}"),
                c("v", "V", "ر", "{"), c("b", "B", "لا", "لآ"), c("n", "N", "ى", "آ"),
                c("m", "M", "ة", "’"), c(",", "<", "و", ","), c(".", ">", "ز", "."),
                c("/", "?", "ظ", "؟"),
                m(SHIFT, "Shift", 2.75f)
        };
        Key[] r5 = new Key[]{
                m(CTRL, "Ctrl", 1.5f),
                special(LANG, "EN", 1.5f),
                m(ALT, "Alt", 1.5f),
                a(KeyEvent.KEYCODE_SPACE, "", 7.5f),
                m(ALT, "Alt", 1.5f),
                m(CTRL, "Ctrl", 1.5f)
        };
        Key[] r6 = new Key[]{
                a(KeyEvent.KEYCODE_DPAD_LEFT, "←", 1f),
                a(KeyEvent.KEYCODE_DPAD_UP, "↑", 1f),
                a(KeyEvent.KEYCODE_DPAD_DOWN, "↓", 1f),
                a(KeyEvent.KEYCODE_DPAD_RIGHT, "→", 1f),
                a(KeyEvent.KEYCODE_MOVE_HOME, "Home", 1.3f),
                a(KeyEvent.KEYCODE_MOVE_END, "End", 1.3f),
                a(KeyEvent.KEYCODE_PAGE_UP, "PgUp", 1.3f),
                a(KeyEvent.KEYCODE_PAGE_DOWN, "PgDn", 1.3f),
                a(KeyEvent.KEYCODE_FORWARD_DEL, "Del", 1.3f)
        };
        return new Key[][]{r0, r1, r2, r3, r4, r5, r6};
    }

    // ---------- lifecycle ----------
    @Override
    public void onCreate() {
        super.onCreate();
        sp = getSharedPreferences("kb", Context.MODE_PRIVATE);
        shiftA = sp.getBoolean("shiftA", true);
        lang = sp.getInt("lang", 0);
    }

    @Override
    public boolean onEvaluateFullscreenMode() {
        return false;
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        for (int i = 0; i < 3; i++) {
            on[i] = false;
            held[i] = false;
            used[i] = false;
        }
        render();
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public View onCreateInputView() {
        Configuration cfg = getResources().getConfiguration();
        boolean night = (cfg.uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        if (night) {
            cTray = 0xFF1F252B;
            cKey = 0xFF353E47;
            cMod = 0xFF28303A;
            cActive = 0xFF3FC2AE;
            cText = 0xFFE8ECEF;
            cOnActive = 0xFF06241F;
        } else {
            cTray = 0xFFCFD5DC;
            cKey = 0xFFFBFCFD;
            cMod = 0xFFE1E6EB;
            cActive = 0xFF0B6B5F;
            cText = 0xFF1A2026;
            cOnActive = 0xFFFFFFFF;
        }
        boolean land = cfg.orientation == Configuration.ORIENTATION_LANDSCAPE;
        int h = dp(land ? 30 : 38);

        all.clear();
        Key[][] rows = buildRows();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        root.setMotionEventSplittingEnabled(true);
        root.setBackgroundColor(cTray);
        root.setPadding(dp(3), dp(3), dp(3), dp(6));

        for (int r = 0; r < rows.length; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setMotionEventSplittingEnabled(true);
            for (final Key k : rows[r]) {
                TextView tv = new TextView(this);
                tv.setGravity(Gravity.CENTER);
                tv.setSingleLine(true);
                tv.setIncludeFontPadding(false);
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, k.size);
                if (k.label != null) tv.setText(k.label);
                tv.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent ev) {
                        int act = ev.getActionMasked();
                        if (act == MotionEvent.ACTION_DOWN) {
                            onDown(k);
                        } else if (act == MotionEvent.ACTION_UP) {
                            onUp(k, true);
                        } else if (act == MotionEvent.ACTION_CANCEL) {
                            onUp(k, false);
                        }
                        return true;
                    }
                });
                k.view = tv;
                all.add(k);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, k.w);
                lp.setMargins(dp(2), dp(2), dp(2), dp(2));
                row.addView(tv, lp);
            }
            int rh = (r == 0) ? (int) (h * 0.75f) : h;
            root.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, rh));
        }
        render();
        return root;
    }

    // ---------- rendering ----------
    private String disp(String s) {
        if (s.length() == 1) {
            char ch = s.charAt(0);
            if (ch >= 0x064B && ch <= 0x0652) return "◌" + s;
        }
        return s;
    }

    private String outChar(Key k, boolean shift) {
        if (lang == 1) return shift ? k.ars : k.ar;
        boolean letter = k.en.length() == 1 && k.en.charAt(0) >= 'a' && k.en.charAt(0) <= 'z';
        if (letter) return (shift != caps) ? k.ens : k.en;
        return shift ? k.ens : k.en;
    }

    private void style(Key k, boolean active) {
        boolean plain = k.type == CHAR || (k.type == ACT && k.code == KeyEvent.KEYCODE_SPACE);
        GradientDrawable gd = new GradientDrawable();
        gd.setCornerRadius(dp(6));
        gd.setColor(active ? cActive : (plain ? cKey : cMod));
        k.view.setBackground(gd);
        k.view.setTextColor(active ? cOnActive : cText);
    }

    private void render() {
        boolean sh = on[SHIFT];
        for (Key k : all) {
            if (k.view == null) continue;
            boolean active = false;
            if (k.type == CHAR) {
                k.view.setText(disp(outChar(k, sh)));
            } else if (k.type == LANG) {
                k.view.setText(lang == 1 ? "ع" : "EN");
            } else if (k.type == MOD) {
                active = (k.mod == CAPS) ? caps : on[k.mod];
            } else if (k.type == TOG) {
                active = shiftA;
            }
            style(k, active);
        }
    }

    // ---------- touch handling ----------
    private boolean repeatable(Key k) {
        if (k.type == CHAR) return true;
        if (k.type != ACT) return false;
        switch (k.code) {
            case KeyEvent.KEYCODE_DEL:
            case KeyEvent.KEYCODE_FORWARD_DEL:
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_SPACE:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_TAB:
            case KeyEvent.KEYCODE_PAGE_UP:
            case KeyEvent.KEYCODE_PAGE_DOWN:
                return true;
            default:
                return false;
        }
    }

    private void onDown(final Key k) {
        k.downAt = SystemClock.uptimeMillis();
        k.consumed = false;
        k.view.setAlpha(0.65f);
        if (k.type == MOD) {
            modDown(k);
        } else if (k.type == LANG) {
            k.longPress = new Runnable() {
                @Override
                public void run() {
                    k.consumed = true;
                    showPicker();
                }
            };
            handler.postDelayed(k.longPress, 600);
        } else if (k.type == TOG) {
            shiftA = !shiftA;
            sp.edit().putBoolean("shiftA", shiftA).apply();
            render();
        } else {
            final boolean sh = on[SHIFT], ct = on[CTRL], al = on[ALT];
            press(k, sh, ct, al, false);
            if (repeatable(k)) {
                k.repeat = new Runnable() {
                    @Override
                    public void run() {
                        press(k, sh, ct, al, true);
                        handler.postDelayed(this, 55);
                    }
                };
                handler.postDelayed(k.repeat, 420);
            }
        }
    }

    private void onUp(Key k, boolean ok) {
        k.view.setAlpha(1f);
        if (k.repeat != null) {
            handler.removeCallbacks(k.repeat);
            k.repeat = null;
        }
        if (k.longPress != null) {
            handler.removeCallbacks(k.longPress);
            k.longPress = null;
        }
        if (k.type == MOD) {
            modUp(k, SystemClock.uptimeMillis() - k.downAt);
        } else if (k.type == LANG && ok && !k.consumed) {
            toggleLang();
        }
    }

    private void modDown(Key k) {
        if (k.mod == CAPS) {
            caps = !caps;
            render();
            return;
        }
        if (k.mod == SHIFT && on[ALT]) {
            on[ALT] = false;
            toggleLang();
            return;
        }
        held[k.mod] = true;
        used[k.mod] = false;
        on[k.mod] = !on[k.mod];
        render();
    }

    private void modUp(Key k, long dur) {
        if (k.mod == CAPS) return;
        held[k.mod] = false;
        if (used[k.mod] || dur > 400) on[k.mod] = false;
        used[k.mod] = false;
        render();
    }

    private void clearOneShot() {
        for (int i = 0; i < 3; i++) {
            if (held[i]) used[i] = true;
            else on[i] = false;
        }
    }

    private void toggleLang() {
        lang = 1 - lang;
        sp.edit().putInt("lang", lang).apply();
        render();
    }

    private void showPicker() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showInputMethodPicker();
    }

    // ---------- sending input ----------
    private int meta(boolean shift, boolean ctrl, boolean alt) {
        int m = 0;
        if (shift) m |= KeyEvent.META_SHIFT_ON | KeyEvent.META_SHIFT_LEFT_ON;
        if (ctrl) m |= KeyEvent.META_CTRL_ON | KeyEvent.META_CTRL_LEFT_ON;
        if (alt) m |= KeyEvent.META_ALT_ON | KeyEvent.META_ALT_LEFT_ON;
        return m;
    }

    private void sendKey(InputConnection ic, int code, int meta) {
        long now = SystemClock.uptimeMillis();
        ic.sendKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_DOWN, code, 0, meta));
        ic.sendKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_UP, code, 0, meta));
    }

    private void ctrlKey(InputConnection ic, char ch, boolean shift, int meta) {
        switch (ch) {
            case 'a':
                ic.performContextMenuAction(android.R.id.selectAll);
                break;
            case 'c':
                ic.performContextMenuAction(android.R.id.copy);
                break;
            case 'x':
                ic.performContextMenuAction(android.R.id.cut);
                break;
            case 'v':
                ic.performContextMenuAction(android.R.id.paste);
                break;
            case 'z':
                ic.performContextMenuAction(shift ? android.R.id.redo : android.R.id.undo);
                break;
            case 'y':
                ic.performContextMenuAction(android.R.id.redo);
                break;
            default:
                if (ch >= 'a' && ch <= 'z') {
                    sendKey(ic, KeyEvent.KEYCODE_A + (ch - 'a'), meta);
                }
        }
    }

    private void press(Key k, boolean shift, boolean ctrl, boolean alt, boolean repeat) {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) {
            int meta = meta(shift, ctrl, alt);
            if (k.type == CHAR) {
                if (ctrl) {
                    ctrlKey(ic, k.en.charAt(0), shift, meta);
                } else if (alt) {
                    // Alt + key does nothing here
                } else if (shiftA && shift && "a".equals(k.en)) {
                    ic.performContextMenuAction(android.R.id.selectAll);
                } else {
                    ic.commitText(outChar(k, shift), 1);
                }
            } else if (k.type == ACT) {
                if (k.code == KeyEvent.KEYCODE_SPACE) {
                    if (!ctrl && !alt) ic.commitText(" ", 1);
                } else {
                    if (k.code == KeyEvent.KEYCODE_ESCAPE) {
                        for (int i = 0; i < 3; i++) on[i] = false;
                    }
                    sendKey(ic, k.code, meta);
                }
            }
        }
        if (!repeat) clearOneShot();
        render();
    }
}
