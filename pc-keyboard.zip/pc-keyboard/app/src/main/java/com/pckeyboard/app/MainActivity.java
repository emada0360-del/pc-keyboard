package com.pckeyboard.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(dp(20), dp(40), dp(20), dp(24));

        TextView title = new TextView(this);
        title.setText("كيبورد PC");
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        title.setGravity(Gravity.START);
        root.addView(title);

        TextView steps = new TextView(this);
        steps.setText("1) اضغط «تفعيل الكيبورد» وشغّل «كيبورد PC».\n"
                + "2) اضغط «اختيار الكيبورد» واختره.\n"
                + "3) جرّب بالحقل تحت: Shift + A يحدد كل النص، وCtrl + A أيضاً.\n\n"
                + "للرجوع لكيبورد ثاني: اضغط مطوّلاً على زر EN / ع.");
        steps.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        steps.setLineSpacing(0f, 1.3f);
        steps.setPadding(0, dp(12), 0, dp(16));
        root.addView(steps);

        Button enable = new Button(this);
        enable.setText("تفعيل الكيبورد");
        enable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS));
            }
        });
        root.addView(enable);

        Button pick = new Button(this);
        pick.setText("اختيار الكيبورد");
        pick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.showInputMethodPicker();
            }
        });
        root.addView(pick);

        EditText test = new EditText(this);
        test.setText("هذا نص تجريبي. جرّب Shift + A.\nThis is a sample line.");
        test.setMinLines(5);
        test.setGravity(Gravity.TOP | Gravity.START);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(16);
        root.addView(test, lp);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.addView(root);
        setContentView(sv);
    }
}
